<?php include('header.php'); ?>
<div class="container">
    <h1>About Our Café</h1>
    <p>Welcome to our cozy little coffee haven where every cup is brewed with love and care. At <strong>Pink Beans Café</strong>, we believe in creating a warm, welcoming space for friends to gather and enjoy premium blends, delicious treats, and good vibes. Whether you're in for a quick espresso or a relaxed afternoon chat, we've got just the spot for you.</p>
</div>
<?php include('footer.php'); ?>
