<?php get_header(); ?>

<div class="home">
    <h1 style="text-align:center;">This is home</h1>
    <p>Write something that presents your cafe</p>
    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>

    <div class="menu">
        <div class="main-content">
            <?php if (have_posts()) : ?>
                <?php while (have_posts()) : the_post(); ?>
                    <div class="post">
                        <h2><?php the_title(); ?></h2>

                        <?php if (has_post_thumbnail()) : ?>
                            <div class="post-thumbnail">
                                <?php the_post_thumbnail('full'); ?>
                            </div>
                        <?php endif; ?>

                        <div class="post-content">
                            <?php the_content(); ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else : ?>
                <p>No menu items found.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Menu Section -->
    <section id="menu" class="menu-section">
        <h2>Our Menu</h2>
        <p class="menu-intro">Freshly brewed coffee and handmade delights</p>

        <div class="menu-items">
            <div class="menu-item">
                <h3>Espresso</h3>
                <p>Strong and bold Italian-style coffee</p>
                <span class="price">€2.50</span>
            </div>
            <div class="menu-item">
                <h3>Cappuccino</h3>
                <p>Rich espresso with steamed milk and foam</p>
                <span class="price">€3.00</span>
            </div>
            <div class="menu-item">
                <h3>Latte</h3>
                <p>Espresso blended with creamy steamed milk</p>
                <span class="price">€3.50</span>
            </div>
            <div class="menu-item">
                <h3>Chocolate Croissant</h3>
                <p>Flaky pastry with a gooey chocolate center</p>
                <span class="price">€2.00</span>
            </div>
            <div class="menu-item">
                <h3>Blueberry Muffin</h3>
                <p>Soft muffin packed with sweet blueberries</p>
                <span class="price">€2.20</span>
            </div>
        </div>
    </section>

    <div class="about-us">
        <?php get_footer(); ?>
    </div>
</div>
