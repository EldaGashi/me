<footer>
    <p>&copy; <?php echo date("Y"); ?> Simple Cafe - All Rights Reserved</p>
    <p>About and contact us</p>
    <p>phone:"#"</p>
    <p>instagram:"..."</p>
</footer>

<?php wp_footer(); ?>

</body>
</html>
