<?php include('header.php'); ?>
<div class="container">
    <h1>Contact Us</h1>
    <p>We'd love to hear from you! Reach out using the form below or visit us at our downtown location.</p>
    <form action="#" method="post" style="max-width: 500px;">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="message">Message:</label><br>
        <textarea id="message" name="message" rows="5" required></textarea><br><br>

        <button type="submit">Send Message</button>
    </form>

    <p style="margin-top: 30px;">📍 Address: 123 Pink Street, Coffee Town<br>
    📞 Phone: (123) 456-7890<br>
    ✉️ Email: hello@pinkbeanscafe.com</p>
</div>
<?php include('footer.php'); ?>
