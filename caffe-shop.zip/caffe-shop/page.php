<?php get_header(); ?>

<header>
    <h1>Welcome to Our Cafe Shop</h1>
    <p>Enjoy our finest coffee and fresh bakery items.</p>
</header>

<div class="main-content">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <div class="post">
            <h2><?php the_title(); ?></h2>

            <?php if (has_post_thumbnail()) : ?>
                <div class="post-thumbnail">
                    <?php the_post_thumbnail('medium'); ?>
                </div>
            <?php endif; ?>

            <p><?php the_excerpt(); ?></p>
            <a class="read-more" href="<?php the_permalink(); ?>">Read More</a>
        </div>
    <?php endwhile; else: ?>
        <p>No posts available.</p>
    <?php endif; ?>
</div>

<footer>
    <p>&copy; 2025 Cafe Shop. All rights reserved.</p>
</footer>

<?php get_footer(); ?>
