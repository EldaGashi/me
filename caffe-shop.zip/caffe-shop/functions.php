<?php

// Theme setup
function simple_cafe_theme_setup() {
    // Enable support for featured images
    add_theme_support('post-thumbnails');

    // Register a navigation menu
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'simple-cafe-theme'),
    ));
}
add_action('after_setup_theme', 'simple_cafe_theme_setup');

// Enqueue stylesheets and scripts
function simple_cafe_theme_enqueue_styles() {
    // Main stylesheet
    wp_enqueue_style('simple-cafe-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
}
add_action('wp_enqueue_scripts', 'simple_cafe_theme_enqueue_styles');

?>
