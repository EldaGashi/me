<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
    <!-- Add Google Fonts for elegant typography -->
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600&family=Playfair+Display:wght@400&display=swap" rel="stylesheet">
</head>
<body <?php body_class(); ?>>
<nav class="navbar">
  <ul>
    <li><a href="#home">Home</a></li>
    <li><a href="#menu">Menu</a></li>
    <li><a href="<?php echo site_url('/about'); ?>">About</a></li>
    <li><a href="<?php echo site_url('/contact'); ?>">Contact</a></li>
  </ul>
</nav>



    <script>
    function scrollToSection(className) {
        const element = document.querySelector('.' + className);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    }
    </script>
     -->

<header>

    <h1><?php bloginfo('name'); ?></h1>
    <p>Experience the Gold Standard in Coffee</p>
</header>
